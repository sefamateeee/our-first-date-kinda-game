lowpoly. free pack · Everything
https://lowpoly.download/free/

197 GLB models (binary glTF 2.0, meters, Y up) for three.js, Godot and Blender.
models.csv lists each file with its triangles and a Studio link to make your own.

License
Royalty-free for commercial use in games, apps, websites, renders and client work.
You can edit, recolor and combine the models and ship them in free or paid projects.
You can't resell or redistribute the models themselves, alone or as a pack.
Full terms: https://lowpoly.download/pricing/#license
